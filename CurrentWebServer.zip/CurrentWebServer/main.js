// Jack Tabb
// 2021-01-10
// Web Server to go in between the bot-configuration app and 
//      the bot.

const express = require('express');
var bodyParser = require('body-parser')
const app = express();

// Bot Parameters //////////////////////////////////////////////////////
let lunch_enabled = true
let lunch_time = "12pm" // time for lunch


let stretch_enabled = true
let stretch_increments = 60 // minutes

let workStart_enabled = true
let workStart_time = "9am" // time for start of workday
////////////////////////////////////////////////////////////////////////

// Web Server Actions //////////////////////////////////////////////////
const cors = require('cors');
//https://www.npmjs.com/package/cors#configuration-options
app.use(cors());
console.log("cors is enabled")

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())

// Lunch
// app.put('/lunch', (req, res) => {
//     res.send('Received lunch params!')

// });
app.get('/lunch', (req, res) => {
    res.json({
        "lunch_enabled" : lunch_enabled,
        "lunch_time" : lunch_time
    });
});

// Stretch
// app.put('/stretch', (req, res) => {
//     res.send('Received stretch params!')
// });

app.get('/stretch', (req, res) => {
    res.json({
        "stretch_enabled" : stretch_enabled,
        "stretch_increments" : stretch_time
    });
});

// Work Start
// app.put('/workStart', (req, res) => {
//     res.send('Received workStart params!')
// });

app.get('/workStart', (req, res) => {
    res.json({
        "workStart_enabled" : workStart_enabled,
        "workStart_time" : workStart_time
    });
});

// Generic Post
app.post('/params', (req, res) => {
    console.log(req.body)
    lunch_enabled = req.body.lunch_enabled
    lunch_time = req.body.lunch_time
    
    stretch_enabled = req.body.stretch_enabled
    stretch_time = req.body.stretch_enabled
    // minutes

    workStart_enabled = workStart_enabled
let workStart_time = "9am" // time for start of workday
    res.send("Received Joey's params!")
});

////////////////////////////////////////////////////////////////////////


app.listen(4000, () => console.log('App listening on port 4000!'));