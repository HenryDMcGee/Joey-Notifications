const axios = require('axios').default;

// Setup Webhook for Card
axios.post('https://webexapis.com/v1/messages', {
    "type": "AdaptiveCard",
    "body": [
        {
            "type": "Image",
            "style": "Person",
            "url": "https://i.imgur.com/Tuzmfi2.png",
            "size": "Medium",
            "height": "50px",
            "horizontalAlignment": "Center"
        },
        {
            "type": "ColumnSet",
            "columns": [
                {
                    "type": "Column",
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": "Tailor Joey To Suit Your Needs",
                            "weight": "Lighter",
                            "horizontalAlignment": "Center",
                            "color": "Attention",
                            "size": "Medium"
                        }
                    ],
                    "width": "stretch"
                }
            ],
            "horizontalAlignment": "Center"
        },
        {
            "type": "Image",
            "style": "Person",
            "url": "https://i.imgur.com/Cc1mngx.png",
            "size": "Small",
            "height": "50px",
            "horizontalAlignment": "Center"
        },
        {
            "type": "TextBlock",
            "weight": "Bolder",
            "text": "Welcome to another day. Lets make it a productive one!",
            "wrap": true,
            "size": "Small",
            "spacing": "Small",
            "horizontalAlignment": "Center",
            "color": "Light"
        },
        {
            "type": "ActionSet",
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Enable Morning Message",
                    "data": {
                        "morning_enabled": true
                    },
                    "style": "positive"
                }
            ],
            "horizontalAlignment": "Center",
            "spacing": "None"
        },
        {
            "type": "Image",
            "style": "Person",
            "url": "https://i.imgur.com/tk9it9e.png",
            "size": "Medium",
            "height": "50px",
            "horizontalAlignment": "Center",
            "spacing": "Small"
        },
        {
            "type": "TextBlock",
            "weight": "Bolder",
            "text": "Lunch alerts also include a daily recipe and stretching or yoga exercises. ",
            "wrap": true,
            "size": "Small",
            "spacing": "Small",
            "horizontalAlignment": "Center",
            "color": "Light"
        },
        {
            "type": "ActionSet",
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Enable Lunch",
                    "data": {
                        "lunch_enabled": true
                    },
                    "style": "positive"
                }
            ],
            "horizontalAlignment": "Center",
            "spacing": "None"
        },
        {
            "type": "Input.ChoiceSet",
            "choices": [
                {
                    "title": "11am",
                    "value": "12pm"
                },
                {
                    "title": "1pm",
                    "value": "2pm"
                }
            ],
            "placeholder": "Time"
        },
        {
            "type": "Image",
            "style": "Person",
            "url": "https://i.imgur.com/G3eUAS1.png",
            "size": "Medium",
            "height": "50px",
            "horizontalAlignment": "Center",
            "spacing": "Small"
        },
        {
            "type": "TextBlock",
            "weight": "Bolder",
            "text": "Lunch alerts also include a daily recipe and stretching or yoga exercises. ",
            "wrap": true,
            "size": "Small",
            "spacing": "Small",
            "horizontalAlignment": "Center",
            "color": "Light"
        },
        {
            "type": "ActionSet",
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Enable Stretch",
                    "data": {
                        "stretch_enabled": true
                    },
                    "style": "positive"
                }
            ],
            "horizontalAlignment": "Center",
            "spacing": "None"
        },
        {
            "type": "Input.ChoiceSet",
            "choices": [
                {
                    "title": "15min",
                    "value": "30min"
                },
                {
                    "title": "45min",
                    "value": "60min"
                },
                {
                    "title": "75min",
                    "value": "90min"
                }
            ],
            "placeholder": "Time Interval"
        }
    ],
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "version": "1.3",
    "backgroundImage": {
        "url": "https://i.imgur.com/lSLya49.png"
    }
})
.then(function (response) {
    // handle success
    console.log(response);
    lunch_enabled = response.data.lunch_enabled
    lunch_time = response.data.lunch_time
})
.catch(function (error) {
    // handle error
    console.log(error);
})