import React, { Component } from 'react';
import './StartScreen.css';

// UI framework component imports
import Appbar from 'muicss/lib/react/appbar';
//Slider
import Slider from '@material-ui/core/Slider';
import Button from '@material-ui/core/Button';

import { createMuiTheme } from '@material-ui/core/styles';
import { ThemeProvider } from '@material-ui/styles';

import axios from 'axios';

import kangarooImage from './logos-08.png';

import pie from './pie.png';

import stretch from './other_icons-05.png';

import sun from './other_icons-03.png';

import background from './gradient-02.png';

export default class StartScreen extends Component {

  // Properties used by this component:
  // appActions, deviceInfo

  constructor(props) {
    super(props);
    console.log("inside constructor we have " + this.props.currentDt)
    this.state = {
      morning_enabled: "disable morning message",
      lunch_enabled: "disable lunch",
      lunch_time: 12,
     
      stretch_enabled: "disable stretch",
      stretch_time: 15
    }
  }

  
  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidUpdate() {
  }
  
  sendJson = () => {
    
    //  let jsonForExport = [
    //         this.state.lunch,
    //         this.state.sliderValue
    //   ];
    let x = false;
    let stretch = false;
    let morning = false;
    if(this.state.lunch_enabled === "enable lunch") {
      x = true;
    }
    
    if(this.state.stretch_enabled === "enable stretch") {
      stretch = true;
    }

    if(this.state.morning_enabled === "enable morning") {
      morning = true;
    }

    let jsonForExport = {lunch_enabled: x,  lunch_time: this.state.lunch_time, stretch_enabled: stretch, stretch_time: this.state.stretch_time, workStart_enabled: morning }
    console.log(jsonForExport)
    axios.post("http://10.0.0.9:4000/params", jsonForExport, { // receive two parameter endpoint url ,form data

    })  
    console.log("sent json")
  }

  alterMorning = () => {
    if(this.state.morning_enabled === "enable morning message") {
     this.setState({
       morning_enabled: "disable morning message"
     })
    } 

    else if(this.state.morning_enabled === "disable morning message") {
     this.setState({
       morning_enabled: "enable morning message"
     })
    } 

    this.sendJson();
 }


  alterLunch = () => {
     if(this.state.lunch_enabled === "enable lunch") {
      this.setState({
        lunch_enabled: "disable lunch"
      })
     } 

     else if(this.state.lunch_enabled === "disable lunch") {
      this.setState({
        lunch_enabled: "enable lunch"
      })
     } 

     this.sendJson();
  }

  lunch_timeHandler = (event, newValue) => {
    this.setState({
      lunch_time: newValue
    })
    console.log(this.state.lunch_time)

    this.sendJson();
  }

  alterStretch = () => {
    if(this.state.stretch_enabled === "enable stretch") {
     this.setState({
      stretch_enabled: "disable stretch"
     })
    } 

    else if(this.state.stretch_enabled === "disable stretch") {
     this.setState({
      stretch_enabled: "enable stretch"
     })
    } 

    this.sendJson();
 }

 stretch_timeHandler = (event, newValue) => {
  this.setState({
    stretch_time: newValue
  })
  console.log(this.state.stretch_time)

  this.sendJson();
}

  render() {

    const theme = createMuiTheme({
      palette: {
        primary1: {
          main: '#ac3814',
        },

        primary2: {
          main: '#F6511D',
        },

        primary3: {
          main: '#f7734a',
        },

        secondary1: {
          main: '#0083a4',
        },

        secondary2: {
          main: '#00BCEB',
        },

        secondary3: {
          main: '#33c9ef',
        },

        basic: {
          black: 'black',
          white: 'white',
        },
      },
      overrides:{
        MuiSlider: {
          thumb:{
          color: '#F6511D',
          },
          track: {
            color: '#F6511D'
          },
          rail: {
            color: 'white'
          }
        }
      }
    });

    const marks = [
      {
        value: 11,
        label: '11am',
      },
      {
        value: 12,
        label: '12pm',
      },
      {
        value: 13,
        label: '1pm',
      },
      {
        value: 14,
        label: '2pm',
      },
    ];

    const stretchTime = [
      {
        value: 15,
        label: '15min',
      },
      {
        value: 30,
        label: '30min',
      },
      {
        value: 45,
        label: '45min',
      },
      {
        value: 60,
        label: '60min',
      },

      {
        value: 75,
        label: '75min',
      },

      {
        value: 90,
        label: '90min',
      },
    ];

    const style_Button = {
      display: 'block',

      color: theme.palette.basic.white,
      textAlign: 'center',
      backgroundColor: theme.palette.primary2.main,
      cursor: 'pointer',
      pointerEvents: 'auto',
    };
    
    const Image = {
      backgroundImage: 'url('+background+')',
      backgroundPosition: '50% 50%',
      backgroundSize: 'cover',
    };

    const Pie = {
      backgroundImage: 'url('+pie+')',
    };

    let layoutFlowStyle = {};
    let baseStyle = {};
    if (this.props.transitionId && this.props.transitionId.length > 0 && this.props.atTopOfScreenStack && this.props.transitionForward) {
      baseStyle.animation = '0.25s ease-in-out '+this.props.transitionId;
    }
    if ( !this.props.atTopOfScreenStack) {
      layoutFlowStyle.height = '100vh';
      layoutFlowStyle.overflow = 'hidden';
    }
    
    
    return (
      <ThemeProvider theme={theme}>
        <div className='Image' style={Image} >
          <div className="Title">
            <img src={kangarooImage} alt="Photo Unavailable" className="Logo"/>
          </div>

          <div className="TextIntro" style={{color:theme.palette.primary2.main}}>
            <p>
              Tailor Joey To Suit Your Company's Needs
            </p>
          </div>

          <img className="sun" src={sun} alt="Photo Unavailable"/>

          <div className="StandardText" style={{color:theme.palette.basic.white}}>
          
          </div>

          <div className="morningContainer" >
            <div className="Text">
              {/* textDecoration: 'underline', textDecorationColor: theme.palette.primary3.main, */}
              <p style={{color:theme.palette.basic.white}}>
                Welcome to another day. Let’s make it a productive one!
              </p>
            </div>

            <div className="Button">
              <Button className="Button" style={style_Button} onClick={this.alterMorning}>
                {this.state.morning_enabled}
              </Button>
            </div>
          </div>

          <img className="pie" src={pie} alt="Photo Unavailable"/>

          <div className="lunchContainer" >
            <div className="Text">
              <p style={{color:theme.palette.basic.white}}>
                Lunch alerts also include a daily recipe and stretching or yoga excercises. 
              </p>
            </div>

            <div className="Button">
              <Button className="Button" style={style_Button} onClick={this.alterLunch}>
                {this.state.lunch_enabled}
              </Button>
            </div>
            <div className="SliderContainer">
              <Slider className="Slider"
                defaultValue={12}
                aria-labelledby="discrete-slider-small-steps"
                step={1}
                marks
                min={11}
                max={14}
                valueLabelDisplay="auto"
                marks={marks}
                onChange={this.lunch_timeHandler}
              />
            </div>
          </div>

          <img className="stretch" src={stretch} alt="Photo Unavailable"/>

          <div className="stretchContainer" >
            <p className="Text" style={{color:theme.palette.basic.white}}>
              Stretch breaks include a video guide. 
            </p>

            <div className="Button">
              <Button className="Button" style={style_Button} onClick={this.alterStretch}>
                {this.state.stretch_enabled}
              </Button>
            </div>
            <div className="SliderContainerStretch">
              <Slider className="Slider"
                defaultValue={15}
                aria-labelledby="discrete-slider-small-steps"
                step={15}
                marks
                min={15}
                max={90}
                valueLabelDisplay="auto"
                marks={stretchTime}
                onChange={this.lunch_timeHandler}
              />
            </div>
          </div>
        </div>
        {/* export the stored content to json to send to Joey */}
      </ThemeProvider>
    )
  }
  
}
