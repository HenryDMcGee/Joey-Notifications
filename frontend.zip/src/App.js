import React, { Component } from 'react';
import { Route, Switch, Redirect, withRouter } from 'react-router-dom';
import * as util from 'util';
import './App.css';

import StartScreen from './StartScreen.js';


class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      screenTransitionForward: true,
    }

  }

  windowDidResize = () => {
    let w = window.innerWidth;
    let formatId;
    if (w < 576) formatId = 'narrow-phone';
    else if (w < 768) formatId = 'wide-phone';
    else if (w < 1024) formatId = 'narrow-tablet';
    else formatId = 'wide-tablet';
    if (formatId !== this.state.screenFormatId) {
      this.setState({screenFormatId: formatId});
    }
  }
  componentDidMount() {
    this.windowDidResize();
    window.addEventListener('resize', this.windowDidResize);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.windowDidResize);
  }

  isLoading() {
    return this.state.loading;
  }

  goToScreen = (screenId, props) => {
    // This method is the default implementation and could be customized by a navigation plugin.
    this.props.history.push('/'+screenId, {...props, appActions: null, locStrings: null, dataSheets: null});
    window.scrollTo(0, 0);
  }

  goBack = () => {
    // This method is the default implementation and could be customized by a navigation plugin.
    this.props.history.goBack();
  }

  render() {
    
    let makeElementForScreen = (screenId, baseProps, atTop, forward) => {
      let screenProps = {
        ...baseProps,
        atTopOfScreenStack: atTop,
        transitionForward: forward,
        appActions: this,
        dataSheets: this.dataSheets,
        locStrings: this.locStrings,
        currentDt: this.currentDt,
        deviceInfo: {
          screenFormatId: this.state.screenFormatId
        },
      };
      switch (screenId) {
        default:
          return null;
        case 'StartScreen':
          return (<StartScreen {...screenProps} />)  
      }
    }
     
    
    return (
        //Switch handles the changing from screen to screen. It inherits props from App.js such as appActions (grants this) for accessing App.js methods.
        //In addition FetchData uses props to pass data to the StartScreen. In doing so this sidesteps the react router. The Api call in FetchData only passes props  to StartScreen.
        //This is because passing props to each other element aka Monday, Tuesday, Wednesday outside of the app.js would prove difficult. Solutions: 1) use  Fetchdata as the source file 
        //and have App.js inherit the props and pass it on to each class. Solution: 2) Don't use react router (react router is very beneficial since it provides a lot of error checking in regards to incorrect url's and overlapping screens)
        //Solution: 3) Call the api in App.js. This is a particularly bad idea since ComponentDidMount is called multiple times and the aquisition of data and processing aka UNIX to UTC can be difficult.
        //Solution 3 is doable however, do to the current stable functionality of the app and inherit hassle of working with React Router (not alot of information, high level coding with the dom requires a fairly complex knowledge of React especially transitioning to a virtual DOM) thus I choose to abstain from this, and instead choose to spend more of my time showing other skills. 
        <div className="App">
          <div>
          </div>
          <Switch>
              <Route path="/" render={(props) => makeElementForScreen('StartScreen', props.location.state, true, true)} exact />
          </Switch>
        </div>
    );
  }
}
export default withRouter(App)
